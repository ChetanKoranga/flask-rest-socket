from flask import Flask
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
# from flask_mail import Mail

from database.db import initialize_db
from flask_restful import Api
from resources.errors import errors
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)
# APP_SETTINGS = '.'
# app.config.from_envvar(APP_SETTINGS)
# mail = Mail(app)

# imports requiring app and mail
from resources.routes import initialize_routes

api = Api(app, errors=errors)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

initialize_db(app)
initialize_routes(api)
