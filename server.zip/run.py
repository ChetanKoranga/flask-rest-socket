from app import app

app.run(port=3500)